<?php echo e($slot); ?>

<?php /**PATH C:\Users\Asus\Desktop\fortify\fortify\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>